<!DOCTYPE html>
<html>
<head>
<!--link to the styling-->
<link rel="stylesheet" href="https://vande433.soisweb.uwm.edu/infost440/FinalProject/styles/css-pokemon-gameboy.css">
</head>
<body>
<!--footer message-->
<div class="framed neutral">
This website was created by Eli VanderMolen. Thank you for viewing my website.<br>
<i> Articles on this website may or may not have false information </i>
</div>
</body>
</html>